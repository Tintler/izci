# İzci — Geliştirme Devir Belgesi

Bu belge, uzun çalışma oturumlarında **context dolduğunda yeni bir chat ile kaldığımız yerden devam edebilmemiz** için tutulur. Tasarım kararları, yapılan işler ve tamamlanma durumları burada işaretlenir.

- **Proje yolu:** `Z:\LLM-Files\izci`
- **Son güncelleme:** 18 Eylül 2026 — Proje planı, mimari kararlar ve yol haritası oluşturuldu. Kod yazımına başlanmadı.
- **Amaç:** Harici HDD'ler takılı değilken de içeriklerini görebilmek; diskleri yerel olarak indeksleyip hızlı tam metin arama sunan, Electron tabanlı masaüstü uygulaması.

---

## 0. Devir protokolü — ÖNCE BUNU OKU

### Yeni chat başlatınca
Aşağıdaki talimatı yapıştır (veya aynısını söyle):

> `Z:\LLM-Files\izci\GELISTIRME.md` dosyasını oku. Yapılmış işlerin işaretlerini (`[x]`) ve "Durum" satırlarını doğrula; kaldığımız geliştirmeden devam et. Yapılan her yeni işi yaptıktan sonra bu dosyada `[ ]` → `[x]` yap ve aşağıdaki "İş işaretleme kuralları"na uy.

### İş işaretleme kuralları
Bir geliştirme maddesi tamamlandığında:

1. İlgili satırın `[ ]` işaretini `[x]` yap.
2. "Durum:" satırını güncelle (`Başlamadı` → `Devam ediyor` → `Bitti`).
3. Altına `- **Yapıldı (TARİH):** ...` şeklinde kısa bir not ekle:
   - Hangi dosyalar değişti
   - Hangi test/doğrulama eklendi veya yapıldı
4. Doğrulama **kullanıcı onayı gerektirir** (aşağıya bak).

### Test / doğrulama ortamı
- Bu proje bir **Electron masaüstü uygulamasıdır**.
- Asistanın **konsol/çalıştırma erişimi yoktur**; testleri, derlemeyi veya uygulamayı kendisi çalıştıramaz. Değişiklikten sonra **kullanıcıdan** ilgili komutu çalıştırıp sonucu yapıştırması istenir.
- **Test komutu:** `npm test` (Node yerleşik `node:test` runner'ı; ek test bağımlılığı yok).
- **Test stratejisi (karar: 2026-09-18):** Birim testleri kullanılır. Electron'a bağımlı olmayan **saf mantık** (SQLite katmanı, indeksleyici, unique-ID çözümleme, FTS5 sorgu kurma) ayrı modüller hâlinde tutulur ve `node:test` ile test edilir. IPC/Electron/pencere davranışı birim testine girmez; onlar kullanıcı tarafında elle doğrulanır. Bu ayrım, test edilebilirlik için main process kodunun ince bir Electron kabuğu + kalın saf-modül katmanı olmasını gerektirir.
- Bir madde ancak **kullanıcı testleri çalıştırıp sonucu onayladıktan** sonra `Bitti` sayılır.

### Kod değişikliği öncesi altın kurallar
- Değişiklikten önce ne yapılacağı söylenir ve onay beklenir. İlgili küçük düzeltmeler tek onay altında gruplanabilir.
- Kullanıcı "durmadan bitir" derse iş sonuna kadar sürdürülür.
- Kullanıcı mesajları **Türkçe**; anahtar/dosya adları **İngilizce ve ASCII** (kodda Türkçe karakter yok).
- Ham istisnalar (`ENOENT`, `EPERM` vb.) kullanıcıya gösterilmez; anlamlı, Türkçe mesaja çevrilir.
- Sürücü harfi **asla** kimlik olarak kullanılmaz (aşağıdaki tasarım kararı).

---

## 1. Kesinleşen tasarım kararları

1. **Kapsam: NTFS-only.** exFAT/FAT32 desteklenmeyecek. Diskler NTFS olduğu için MFT + USN journal kullanılabilir.
2. **Index motoru Faz 1:** Node.js (`fs.readdir` ile özyinelemeli directory-walk). Derleme gerektirmez, admin gerektirmez, her koşulda çalışan taban.
3. **Index motoru Faz 2:** `$MFT` ham volume (`\\.\X:`) üzerinden okunup parse edilecek. Saf JS ile denenecek; **admin yetkisi ister**, performans kazancı garanti değil — test edilip doğrulanacak. Rust/MSVC yok; toolchain kurulumu ancak ölçüm sonrası gerekirse gündeme gelir.
4. **Admin:** Uygulama "yönetici olarak çalıştır" beklentisiyle kurulur. Yetki yoksa anlamlı Türkçe uyarı verilir ve Faz 1 moduna düşülür.
5. **UI:** Vanilla + Vite (React yok). Renderer düz HTML/CSS/JS; `contextIsolation` açık, tüm veri `main`/IPC üzerinden.
6. **Depolama:** SQLite (tek dosya, uygulamanın kendi veri klasöründe — HDD'de değil). FTS5 ile tam metin arama.
7. **Unique ID:** Fiziksel disk seri numarası (`Win32_DiskDrive.SerialNumber`) birincil kimlik; volume serial number yedek anahtar.
8. **Disk algılama:** `WM_DEVICECHANGE` olayları; polling yok. Program kapalıyken hiçbir şey çalışmaz.
9. **Index seçimi (opt-in):** Ana ekranda **yalnızca indekslenen diskler** görünür. Varsayılan olarak hiçbir disk indekslenmez. Yeni disk ekleme, ayrı bir "Disk Ekle / Bağlı diskler" görünümünden yapılır (ana ekranı kirletmez).
10. **Custom label:** Her disk için program içinde yaşayan, diskin kendi volume label'ından bağımsız serbest metin etiket. Disk bağlı değilken de görünür.
11. **Hariç tutma:** Disk seviyesinde (tüm diski indeksleme dışı bırakma). Klasör seviyesinde hariç tutma **yok** (kullanıcı talebi).

### SQLite şema taslağı
```
drives(
  hw_id TEXT PK,        -- fiziksel disk seri no (birincil kimlik)
  volume_serial TEXT,   -- yedek anahtar
  current_letter TEXT,  -- F:, G: ... her takılışta güncellenir
  fs_type TEXT,
  total_bytes, used_bytes, free_bytes,
  volume_label TEXT,    -- diskin kendi etiketi
  custom_label TEXT,    -- kullanıcının verdiği etiket
  indexed INTEGER,      -- 0/1, opt-in
  connected INTEGER,    -- 0/1
  last_seen, last_indexed
)
entries(
  id, hw_id FK, parent_id, name, path, is_dir, size, mtime
)
entries_fts(name, path)   -- FTS5 sanal tablo
```

### Mockup
`Z:\LLM-Files\izci\mockup\mockup.html` — tarayıcıda açılır, bağımlılıksız. Ana ekran (disk kartları) ve arama ekranı görünümünü gösterir. (Not: mockup'ta bağlı diskler de görünüyor; gerçek uygulamada ana ekran **yalnızca indekslenenleri** gösterir.)

---

## 2. Yol haritası (öncelik sıralı)

> Her maddenin "Durum:" satırını güncelle. Bitince `[x]` yap ve 0. bölümdeki kurallara uy.

### G1. Proje iskeleti ve test stratejisi
- [x] **Durum:** Bitti
- **Yapılacaklar:**
  - Electron + Vite iskeleti (main/renderer/preload ayrımı, `contextIsolation` açık).
  - `DRIVE_SCAN` / `DRIVE_ADD` / `INDEX_START` / `SEARCH` gibi IPC kanallarının sözleşmesini tanımla.
  - SQLite katmanı: bağlantı, şema göçü (migration), tabloların oluşturulması.
  - **Test stratejisi:** Birim testleri (`npm test`, `node:test`). Elektron'a bağımsız saf modüller test edilir. (Karar: 2026-09-18 — bkz. 0. bölüm.)
  - `package.json` ile `npm test` betiğini bağla.
- **Yapıldı (2026-09-18):**
  - `package.json` (`type: module`, `test: node --test`), `vite.config.js`, `.gitignore` oluşturuldu.
  - Saf çekirdek modüller: `src/core/bytes.js` (`formatBytes`, `usedPercent`), `src/core/driveKey.js` (`normalizeHardwareId`, `resolveDriveKey`, `normalizeLetter`), `src/core/schema.js` (şema + `detectFts` + `applySchema`), `src/core/database.js` (`openDatabase`, `upsertDrive`, `listIndexedDrives`, `listAllDrives`, `markDisconnected`, `setDriveIndexed`, `setCustomLabel`, `setLastIndexed`).
  - Electron kabuğu: `src/main/main.js` (ince kabuk + IPC handler'lar), `src/main/preload.cjs` (contextBridge köprüsü), `src/shared/channels.js` (IPC sözleşmesi).
  - Renderer: `src/renderer/index.html`, `styles.css`, `main.js` (mockup'taki kart görünümüne dayalı).
  - Birim testleri: `tests/bytes.test.js`, `tests/driveKey.test.js`, `tests/database.test.js`, `tests/schema.test.js`.
  - **Depolama seçimi:** `node:sqlite` (Node yerleşik, native derleme yok — MSVC gerekmez). **Node >= 22.5.0** şartı `package.json` `engines` alanına yazıldı.
  - FTS5 varlığı `detectFts` ile çalışma anında tespit edilir; yoksa arama LIKE tabanına düşecek (G5'te tamamlanacak).
- **Tamamlanma ölçütü:** Uygulama açılıp boş ana ekranı Electron penceresinde gösteriyor; SQLite şeması oluşuyor; `npm test` geçiyor.
- **Doğrulama:** `node -v` → **v24.21.0**; `npm test` → **24/24 pass, 0 fail** (2026-09-18, kullanıcı tarafında). `node:sqlite` ve `detectFts` sorunsuz çalıştı.
- **Not (2026-09-18):** `npm install` sırasında Electron binary indirmesi kullanıcı tarafından iptal edildi (hata kodu `3221225786` = `STATUS_CONTROL_C_EXIT`, gerçek hata değil). Birim testleri Electron'a bağımlı olmadığı için etkilenmedi. Electron kurulumu ayrıca tamamlanacak.
- **Not (2026-09-18):** Bağımlılık sürümleri güncellendi: `electron ^44.4.0` (stable 44.4.0), `vite ^8.2.0`. İlk yazılan `^37`/`^6` değerleri eskiydi (cutoff sonrası sürümler).

### G2. Disk algılama, unique ID ve custom label
- [x] **Durum:** Bitti
- **Karar (2026-09-18):** `WM_DEVICECHANGE` olay dinleyicisi **istenmiyor**. Kullanıcı manuel "Yenile" ile taramayı seçti. Arka planda sürekli dinleme/polling yok.
- **Yapılacaklar:**
  - Bağlı diskleri listele: harf, fs tipi, toplam/dolu/boş, volume label, fiziksel disk seri no.
  - `hw_id` ile DB'ye yaz/güncelle; harf değişse bile kimlik sabit kalır.
  - `custom_label` düzenleme (main tarafı + IPC).
  - `connected` durumu: tarama öncesi tüm diskler `markAllDisconnected` ile 0 yapılır, görülenler 1'e döner.
- **Yapıldı (2026-09-18):**
  - `src/core/driveScan.js` (saf): `parseDriveScan` (JSON dizi/tek nesne), `normalizeScannedDrive` (hem camelCase hem WMI alan adları), `usableDrives` (kimliksiz/harfsiz kayıtları eler).
  - `src/main/driveProbe.js` (ince kabuk): `scanDrives()` — PowerShell `Get-Partition`/`Get-Volume`/`Get-Disk` çağırır, JSON'u döndürür. Birim testine girmez.
  - `src/core/database.js`: `markAllDisconnected` eklendi.
  - `src/main/main.js`: `DRIVE_SCAN` handler artık `refreshDrives()` çağırır (tara → `markAllDisconnected` → `upsertDrive`).
  - Renderer: "Yenile" butonu, "Diskler" (yalnızca indekslenen) ve "Disk ekle" (bağlı tüm diskler) görünümleri; kartlarda indeksle anahtarı + etiket düzenleme.
  - Testler: `tests/driveScan.test.js` (9 test), `tests/database.disconnect.test.js` (1 test).
- **Tamamlanma ölçütü:** Aynı disk iki farklı harfle takılınca tek kart olarak görünür; çıkarılınca "bağlı değil" olur, son görülme tarihi korunur; custom label kalıcı.
- **Doğrulama:** `npm test` → **34/34 pass, 0 fail** (2026-09-18, kullanıcı tarafında). Electron kuruldu, uygulama açıldı, "Yenile" ile gerçek diskler görüntülendi.
- **Açık kalan (dürüst not):** "Aynı disk iki farklı harfle takılınca tek kart" senaryosu gerçek donanımda henüz test edilmedi; tasarım gereği garanti (kimlik `hw_id`, harften bağımsız). Kullanıcı uygun bir zamanda çıkar/tak ile doğrulayabilir.

### G3. Index seçimi (opt-in) ve disk ekleme görünümü
- [x] **Durum:** Bitti
- **Yapıldı (2026-09-18):** G2 sırasında tamamlandı. Ana ekran yalnızca `indexed=1`; "Disk ekle" görünümü tüm diskleri listeler; indeksle anahtarı `indexed` bayrağını yönetir.
- **Doğrulama:** Kullanıcı tarafında — "Disk ekle"den indeksle → "Diskler"de görünüyor; kapatıp açınca anahtar açık ve disk görünür kalıyor (2026-09-18).
- **Ek düzeltme (2026-09-18):** `window.prompt` Electron'da çalışmıyor (sessizce `null` dönüyor, etiket penceresi açılmıyordu). Kendi HTML modal'ı (`labelModal`) yazıldı; iptal = işlem yok, boş kaydet = etiketi sil. Kullanıcı tarafından doğrulandı.

### G4. Faz 1 indeksleyici (directory-walk)
- [x] **Durum:** Bitti
- **Yapılacaklar:**
  - `fs.readdir(..., { withFileTypes: true })` ile özyinelemeli tarama; ilerleme bildirimi (progress).
  - Sonuçları `entries` + `entries_fts` tablolarına toplu yaz (batch insert, transaction).
  - Yalnızca `indexed=1` diskler taranır.
  - `last_indexed`, dosya sayısı kaydı.
- **Yapıldı (2026-09-18):**
  - `src/core/walkTree.js` (saf): `walkTree(root, fsOps, { onEntry, excludeDirs })` — `fsOps` enjekte edilir (test için sahte FS). `normalizePath` dışa açıldı. Erişilemeyen klasör `error` alanıyla bildirilir, tarama durmaz.
  - `src/core/indexWriter.js` (saf): `createIndexWriter(db, hwId, { batchSize })` — `parent_id` **flush anında** çözülür (üst kayıt aynı partide olabilir); `BEGIN/COMMIT` transaction, hata → `ROLLBACK`.
  - `src/main/indexRunner.js` (ince kabuk): gerçek `fs` + `walkTree` + `createIndexWriter`; `onProgress` 5000 kayıtta bir.
  - `src/core/database.js`: `clearDriveEntries`, `countDriveEntries` eklendi.
  - `src/main/main.js`: `INDEX_START` → `startIndex`; `INDEX_PROGRESS` olayı renderer'a gönderilir.
  - `src/shared/channels.js` + `preload.cjs`: `INDEX_PROGRESS` + `onIndexProgress` köprüsü.
  - Renderer: indekslenen kartlarda "Şimdi tara" (↻) butonu + ilerleme notu; sonuç `alert` ile özetlenir.
  - Testler: `tests/walkTree.test.js` (5), `tests/indexWriter.test.js` (4) — sahte FS ve gerçek in-memory SQLite ile.
- **Tamamlanma ölçütü:** Gerçek bir HDD taranıp dosyalar DB'ye yazılıyor; uygulama yeniden açıldığında indeks duruyor (disk takılı değilken de görünür).
- **Doğrulama:** `npm test` (kullanıcı tarafında) + uygulamada bir diskte "Şimdi tara" ve süre ölçümü.
- **Ölçüm (2026-09-18, kullanıcı tarafında):** NVMe disk, **237.643 kayıt / 209.466 dosya → 28 saniye**. Harici HDD (K-5, G:, 5 TB, NTFS), ~5.000 kayıt → **5 saniye**.

- **G4b — diff modu (2026-09-18, kullanıcı talebi):** İlk sürüm her taramada `clearDriveEntries` ile indeksi silip sıfırdan yazıyordu. İki sorun: (a) gereksiz yazım, (b) **yarıda kesilirse indeks boş kalır**. Diff moduna çevrildi:
  - `loadExistingEntries`: diskteki mevcut kayıtlar belleğe yüklenir.
  - `createIndexWriter`: `mtime + size + is_dir` aynı olan kayıt **yeniden yazılmaz** (id korunur, FTS tetiklenmez); değişenler `UPDATE` ile güncellenir; yeni olanlar `INSERT`.
  - `finalize()`: tarama sonunda görülmeyen kayıtlar (silinen dosyalar) temizlenir. Dönen değer: `{ walked, written, skipped, removed }`.
  - `clearDriveEntries` kaldırıldı; `indexRunner` artık silme yapmıyor.
  - Testler: `indexWriter.test.js` diff senaryolarıyla genişletildi (değişmeyen→skip/id korunur, değişen→update, silinen→removed, yeni→insert).
  - **Doğrulama (2026-09-18, kullanıcı tarafında):** `npm test` → **47/47 pass**; `npm run build` temiz; HDD (G:, 5 TB) taraması ~5 sn. Diff sayaçları (`walked/written/skipped/removed`) `alert` mesajına eklendi (ilk sürümde gizliydi; ikinci taramanın gerçekten hızlı/atlamalı olduğu ancak bu sayaçlarla görülebilir).
  - **Kalan maliyet (dürüst not):** Gezme (readdir+stat) hâlâ tüm ağaçta yapılır; diff yalnızca **DB yazımını** ve riski azaltır. Gerçek "sadece değişeni gez" için NTFS USN journal gerekir (G7) ve saf JS ile mümkün değil.

- **Not:** Tarama şu an `main` process'te (async `fs`, event loop'u tam bloklamaz ama ağır diskte UI yavaşlayabilir). Gerekirse G6/USN sonrası `worker_threads`'e taşınır — şimdilik ölçüm bekleniyor.
- **Doğrulama (G4b diff, 2026-09-18, kullanıcı tarafında):** `npm test` → **47/47 pass**; `npm run build` temiz. Aynı HDD iki kez tarandı; ikinci taramada sayaçlar atlama gösterdi (kullanıcı onayı: "Oldu").

### G5. Tam metin arama (FTS5)
- [x] **Durum:** Bitti
- **Yapıldı (2026-09-18):**
  - `src/core/search.js` (saf): `tokenizeQuery`, `buildFtsQuery` (jetonları tırnaklar + önek `*` ekler → FTS5 özel karakterleri nötrlenir), `searchEntries`. FTS5 varsa `entries_fts MATCH ... ORDER BY rank`; yoksa `LIKE ... ESCAPE '\\'` tabanına düşer (`%`, `_` kaçırılır). Sonuçlar normalize edilir (disk etiketi `custom_label || volume_label`).
  - `src/main/main.js`: `SEARCH` handler + `ftsAvailable` durumu `openDatabase`'ten alınır.
  - Renderer: üstteki arama kutusu (Enter) + "Arama" görünümü; eşleşme vurgusu (`highlight`), disk/sütun gösterimi, `escapeHtml` ile XSS koruması.
  - Testler: `tests/search.test.js` (11 test) — tokenize, FTS sorgu kaçışı, FTS5 gerçek MATCH, LIKE yedeği, limit, normalize alanlar.
- **Tamamlanma ölçütü:** İndekslenen diskte bir isim aranınca hızlı sonuç gelir; liste akıcı kaydırılır.
- **Doğrulama:** `npm test` (kullanıcı tarafında) + uygulamada arama.
- **G5b — kullanıcı geri bildirimi (2026-09-18):**
  - Arama kutusu boşaltılınca eski sonuçlar kalıyordu → `input` olayında `clearResults()` + özet sıfırlanır.
  - Limit 300 çok düşüktü → `DEFAULT_LIMIT` 5000, `MAX_LIMIT` 100000.
  - Sonuç listesi artık **sanallaştırılmış**: `.res-viewport` + `resultSpacer` (toplam yükseklik) + `renderWindow()` (yalnızca görünen ±5 satır, `ROW_HEIGHT=34`). Böylece 10 binlerce satır DOM'u kilitlemez.
  - Kaydırma çubukları koyu temaya uyduruldu (`::-webkit-scrollbar*`, `color-scheme: dark`).
- **G5c — kullanıcı geri bildirimi (2026-09-18):** Sonuç tablosundaki "Yol" sütunu artık **yalnızca dizini** gösterir (dosya adı tekrarlanmaz). `search.js` içine saf `dirName()` eklendi; `mapRow` çıktısına `dir` alanı eklendi; renderer `r.dir` gösterir. Testler: `dirName` (4) + `dir` alanı doğrulaması (1).
- **Doğrulama:** `npm test` → **58/58 pass** (2026-09-18, kullanıcı tarafında); arama 4k kaydı tek seferde getirdi, boş input sonuçları temizledi (kullanıcı onayı).
- **G5d — kullanıcı geri bildirimi (2026-09-18):** Sonuçlarda klasör/dosya ayrımı ve ikonlar:
  - `src/core/icons.js` (saf): `extensionOf`, `iconKind` → `folder | image | video | audio | file`. Uzantı kümeleri (görsel/video/ses).
  - `search.js`: `mapRow` çıktısına `iconKind` eklendi. Sıralama: FTS ve LIKE yollarında **`is_dir DESC`** (klasörler önce); LIKE yolunda ek `name COLLATE NOCASE`.
  - Renderer: Material Symbols ikonları **inline SVG** olarak gömüldü (`ICON_PATHS`) — asset/pipeline derdi yok. Ad sütununda ikon + isim; klasör ikonu accent renkli (`.is-folder`).
  - Testler: `tests/icons.test.js` (7) + search sıralama/iconKind (2).
  - **Not:** Kullanıcının verdiği `Z:\LLM-Files\izci-simge-ikon\icons` altındaki SVG'ler okunup path verileri gömüldü; dosya bağımlılığı yok. `src/renderer/icons` (boş dizin) kullanılmadı.
- **Doğrulama (G5d):** `npm test` → **72/72 pass** (2026-09-18, kullanıcı tarafında). Kullanıcı onayı: sonuç görünümü ve ikonlar iyi.

### G8. Klasör gezintisi (browse)
- [ ] **Durum:** Kod tamam — kullanıcı testi bekliyor
- **Bağlam:** Uygulamada yalnızca arama vardı; bir diske girip klasör klasör gezme yoktu. Amaç (takılı değilken içeriği görmek) için gezinti gerekli.
- **Yapılacaklar:**
  - Disk kartına tıklayınca o diskin kök içeriği listelenir.
  - Klasöre tıklayınca içine girilir; breadcrumb + geri butonu.
  - Aynı sanallaştırma ve dosya ikonları (G5d) kullanılır.
- **Yapıldı (2026-09-18):**
  - `src/core/browse.js` (saf): `listChildren(db, hwId, parentId, { limit })` — kök için `parent_id IS NULL`, alt klasör için `parent_id = ?`; sıralama `is_dir DESC, name COLLATE NOCASE`; `iconKind` + `dir` alanları.
  - `src/shared/channels.js` + `preload.cjs`: `FOLDER_LIST` / `listFolder(hwId, parentId)`.
  - `src/main/main.js`: `FOLDER_LIST` handler.
  - Renderer: `viewBrowse` görünümü, breadcrumb, geri butonu, kart tıklaması; arama ve gezinti için ortak sanallaştırma fabrikası (`createVirtualList`).
  - Testler: `tests/browse.test.js`.
- **Doğrulama:** `npm test` bekleniyor (~80 test) + uygulamada gezinme.
- **Not:** `listChildren` bir klasörün tüm çocuklarını tek sorguda getirir (limit 20000). `breadcrumb` parent zincirini 1000 adım güvenlik sınırıyla yürür.

### G9. G6/G7 (MFT + USN) — Rust kararı bekliyor
- [ ] **Durum:** Başlamadı (bloke) — **kullanıcı kararı (2026-09-18): şu an gerek yok**
- **Bağlam:** NTFS `$MFT` ve USN journal saf JS ile okunamaz; `DeviceIoControl` + `FSCTL_*` gerekir → Rust/napi-rs. Rust toolchain kullanıcıda yok.
- **Karar:** Mevcut ölçümler iyi (HDD 5k=5 sn, NVMe 237k=28 sn). Gerçek bir HDD'de büyük hacim kabul edilemez çıkarsa Rust kurulumu gündeme gelir. **G6/G7/G9 şimdilik askıda; sürekli sorulmayacak.**

### G10. Görsel kimlik ve ikonlar
- [x] **Durum:** Bitti
- **Yapıldı (2026-09-18):**
  - **Logo:** topbar'da metnin solunda 4 mavi daireden oluşan mark (inline SVG) + `iz` beyaz / `ci` mavi metin.
  - **Disk ikonu:** kart ikonu artık Material disk SVG'si (kullanıcının verdiği `izci-disk.svg` path'i + mavi çubuk).
  - **Program ikonu:** `build/izci.ico` / `build/izci-mark-256.png` varsa pencere + uygulama ikonu yapılır (`appIconPath()`). `.exe` sembolü için `electron-builder` yapılandırması (`package.json` `build.win.icon`) eklendi; `npm run dist` ile derlenir.
  - **İkonlar kopyalandı:** `build\izci.ico`, `build\izci-mark-256.png` (2026-09-18, kullanıcı tarafında).
  - **Paketleme:** `electron-builder` kuruldu; `npm run dist` çalıştı. Çıktılar: `release\Izci 0.1.0.exe` (portable, tek dosya) ve `release\win-unpacked\Izci.exe`. `appId=com.izci.app`, `productName=Izci`, `win.icon=build/izci.ico`.
  - **Not:** `package.json`'da `author` alanı yok — electron-builder uyardı (hata değil). İstenirse eklenir.
  - **DB konumu (2026-09-18, kullanıcı talebi):** Portable exe'de DB, exe'nin bulunduğu klasöre yazılır (`process.env.PORTABLE_EXECUTABLE_DIR` → `izci.db`). Dev/normal çalıştırmada `app.getPath('userData')` → `%APPDATA%\izci\izci.db`. İki ortamın DB'si ayrıdır. Salt-okunur klasörde portable DB yazılamaz (bilinen sınır).
- **Doğrulama:** `npm test` → **88/88 pass**; `npm run dist` başarılı (2026-09-18, kullanıcı tarafında).

### G11. Kolon boyutlandırma + düzen
- [x] **Durum:** Bitti
- **Yapıldı (2026-09-18):**
  - `src/core/columns.js` (saf): `defaultPercents`, `applyResize` (yüzde tabanlı, komşu ters kayar, min 60px), `serializePercents`, `parsePercents`.
  - Renderer: `res-head` sütun kenarlarına `col-resizer` tutamacı; sürükleyince `--c0..--c3` CSS değişkenleri güncellenir; `localStorage` (`izci.columnPercents`) ile hatırlanır.
  - **Düzen:** view'lar `display:flex; flex-direction:column; height:100%` yapıldı; liste `flex:1` ile aşağı uzuyor → arama/gezinti altındaki boşluk giderildi.
  - Testler: `tests/columns.test.js` (8).
- **Doğrulama:** `npm test` (kullanıcı tarafında) + uygulamada sürükleme ve kalıcılık. Kullanıcı onayı (2026-09-18): kolon boyutlandırma, gap, logo, disk ikonu ve exe sembolü düzgün; portable DB exe yanında oluştu.

### G14. Çoklu dil (TR/EN)
- [x] **Durum:** Bitti
- **Yapıldı (2026-09-18):**
  - `src/core/i18n.js` (saf): `t(lang, key, params)` (eksik anahtar → anahtarın kendisi), `resolveLang`, `isSupportedLang`, `keysOf`, `LANGS`, `DEFAULT_LANG`. TR/EN sözlükleri aynı anahtar kümesinde.
  - Renderer: tüm statik metinler `data-i18n` / `data-i18n-attr="placeholder:key"`; dinamik metinler `tr()` üzerinden. Dil `localStorage` (`izci.lang`) ile hatırlanır.
  - Üst menüde sağda **TR/EN** açılır seçici (`#langSelect`). Dil değişince statik + dinamik içerik yeniden çizilir.
  - Testler: `tests/i18n.test.js` (8).
- **Doğrulama:** `npm test` → **112/112 pass** (2026-09-18, kullanıcı tarafında). Uygulamada TR/EN geçişi (statik + açık arama/gezinti listeleri yeniden çizilir) kullanıcı onaylı.

### G13. GitHub hazırlığı, toplam boyut, exe adı
- [x] **Durum:** Bitti
- **Yapıldı (2026-09-18):**
  - `.gitignore`: `node_modules/`, `dist/`, `release/`, `GELISTIRME.md`, `*.db*` — yalnızca gerekliler.
  - `README.md` (İngilizce): tanıtım, özellikler, gereksinimler, hızlı başlangıç, test, paketleme, mimari, sınırlamalar.
  - `USAGE.md` (İngilizce): ekran ekran kullanım kılavuzu.
  - `package.json`: `build.artifactName = "izci.${ext}"` → çıktı artık `release/izci.exe`.
  - **Toplam boyut:** ana ekranda indekslenen disklerin özet çubuğu (`#driveTotals`): disk sayısı, bağlı sayısı, toplam kapasite, dolu, boş.
- **Ek (2026-09-18):** README kısaltıldı (tanıtım/özellikler/gereksinimler/hızlı başlangıç/doküman linki); test, paketleme ve proje düzeni USAGE.md'ye taşındı. USAGE.md tamamen İngilizce (Türkçe arayüz terimleri kaldırıldı).
- **Doğrulama:** `npm test` → 112/112; `npm run build` temiz. Uygulamada özet çubuğu ve `npm run dist` → `release/izci.exe` kullanıcı onaylı (2026-09-18).
- **Release notu (2026-09-18):** GitHub release'e yalnızca `izci.exe` yüklenir. `builder-effective-config.yaml`, `builder-debug.yml` ve `win-unpacked/` dağıtım dosyası değildir (hata ayıklama/yerel test çıktıları). `release/` zaten `.gitignore`'da.

### G12. Sıralama, sol menü ikonu ve menü çubuğu
- [x] **Durum:** Bitti
- **Yapıldı (2026-09-18):**
  - `src/core/sorting.js` (saf): `resolveOrderBy` (whitelist → güvenli SQL `ORDER BY`, klasörler önce, NULL'lar sonda), `sortByKind` (bellekte tür sırası: folder→image→video→audio→file).
  - `searchEntries` ve `listChildren` artık `sortBy`/`desc` alıyor; varsayılan **isim** (A→Z). `kind` sırası bellekte yapılır.
  - IPC/preload: `search(query, sortBy, desc)`, `listFolder(hwId, parentId, sortBy, desc)`.
  - Renderer: başlıklar `.sortable`; tıkla → artan/azalan geçiş, ok göstergesi (▲/▼). Arama ve gezinti sıralamaları ayrı tutulur.
  - **Sol menü:** "Diskler" ikonu kullanıcının verdiği `hard_disk` SVG'siyle değiştirildi.
  - **Menü çubuğu:** `Menu.setApplicationMenu(null)` ile File/Edit/Window menüsü kaldırıldı.
  - Testler: `tests/sorting.test.js` (10) + search/browse sıralama testleri.
- **Doğrulama:** `npm test` → **103/103 pass** (2026-09-18, kullanıcı tarafında); uygulamada sıralama/menü/ikon kullanıcı onaylı.

### G6. Faz 2: MFT tabanlı hızlı indeksleme
- [ ] **Durum:** Başlamadı (ölçüm sonrası karar)
- **Sorun/bağlam:** G4 directory-walk, 2M dosyalı bir diskte dakikalarca sürebilir. NTFS `$MFT` okunarak bu saniyelere inebilir.
- **Yapılacaklar:**
  - Ham volume (`\\.\X:`) üzerinden `$MFT` okuması (admin gerekir) — saf JS ile denenecek; çalışmazsa Rust napi-rs addon değerlendirilir.
  - G4 ile aynı çıktı sözleşmesi (aynı tablolar).
  - Yetki yoksa otomatik Faz 1'e düş.
- **Tamamlanma ölçütü:** G4 ile aynı sonucu, ölçülebilir biçimde belirgin daha hızlı üretiyor **VEYA** saf JS ile yapılamadığı kanıtlanıp Rust kararı veriliyor.
- **Doğrulama:** (kullanıcı tarafında; iki motorun süre karşılaştırması)

### G7. Artımlı güncelleme (USN journal)
- [ ] **Durum:** Başlamadı
- **Yapılacaklar:**
  - NTFS USN journal ile "son indekslemeden bu yana ne değişti" yakala; tüm diski yeniden gezme.
- **Tamamlanma ölçütü:** Disk yeniden takıldığında tam tarama yerine yalnızca değişenler işlenir.
- **Doğrulama:** (kullanıcı tarafında)

### G15. Gezintide Back butonu ve indeks kapatma onayı
- [x] **Durum:** Bitti
- **Yapıldı (2026-09-18):**
  - **Back butonu:** Kök dizindeyken (geri gidilecek yer yokken) buton `disabled` + soluk; tooltip `browse.atRoot`. Yanıltıcı tıklama kaldırıldı. `updateBrowseBack()`; dil değişiminde de çağrılır.
  - **İndeks kapatma onayı:** Açık bir İndeksle anahtarına basıp kapatmak istenirse genel onay modalı (`#confirmModal`, `askConfirm`) çıkar. İptal → işlem yapılmaz, toggle açık kalır. Onayla → kapatılır. Modal Esc/arka plan/İptal = iptal. Metin i18n'de (`confirm.disableTitle`/`confirm.disableBody`).
- **Doğrulama:** `npm test` → 112/112; uygulamada kullanıcı onaylı (2026-09-18).

### G16. Kompakt görünüm (Drives + Add drive)
- [x] **Durum:** Bitti
- **Yapıldı (2026-09-18):**
  - **İki görünüm:** Normal (açık kartlar) ↔ Kompakt (sade kartlar: ad + harf + doluluk yüzdesi + ince bar).
  - **Kompakt modda yok:** indeks anahtarı, etiket düzenleme, tarama butonu (kullanıcı talebi). İndeksli karta tıklayınca gezinti açılır.
  - **Tek buton:** Bölüm başlığının sağında, **ikon-only** (Normal → `expand_all`, Kompakt → `collapse_all`), tooltip'li. "Tümünü aç/kapat" ayrı butonlar kaldırıldı; buton modlar arası geçiş yapar.
  - **Varsayılan:** Her açılışta **Normal** başlar (kalıcı değil; bilinçli olarak `localStorage`'a yazılmaz).
  - **Statü:** Kompakt kartta satır içi renkli nokta (yüzdeyle çakışma giderildi).
  - **Harf (G:/F:):** Yalnızca disk **bağlıyken** gösterilir (normal + kompakt). Bağlı değilken gizli.
  - Testler: yok (UI davranışı; elle doğrulanır). i18n anahtarları TR/EN eşlendi.
- **Doğrulama:** `npm test` → 112/112; `npm run build` temiz; uygulamada kullanıcı onaylı (2026-09-18).
- **Bilinen kısıt (kullanıcı kabul etti):** Kompakt modda "Disk ekle" sayfasında indeks anahtarı görünmez; yeni disk eklemek için Normal'e geçmek gerekir.

### G17. GitHub başlık logosu
- [x] **Durum:** Bitti
- **Yapıldı (2026-09-18):** README üst başlığı için ortalanmış logo. `assets/logo-dark.svg` (koyu tema, `#f0b82e`) + `assets/logo-light.svg` (açık tema, daha koyu turuncu) `<picture>` ile tema bazlı seçilir. Program içi başlık stiliyle (tek renk, `Segoe UI`, weight 600) uyumlu. (Cevirgec projesi için de aynı yaklaşım uygulandı.)
- **Doğrulama:** Kullanıcı tarafında GitHub önizlemesinde onaylı.

---

## 3. Belge görevleri

- **GELISTIRME.md:** Bu dosya. Tasarım kararları, tamamlanan/bekleyen işler ve doğrulama kayıtları burada tutulur.
- **README.md:** GitHub ana sayfası — kısa tanıtım, özellikler, gereksinimler, hızlı başlangıç, USAGE bağlantısı.
- **USAGE.md:** Kullanıcı kılavuzu (İngilizce): ekranlar, indeksleme, arama, gezinme, sıralama, dil, veri konumu, exe derleme, test, proje düzeni, sınırlamalar.
- **LICENSE:** MIT (kullanıcı tarafından eklendi).

---

## 4. Proje durumu (2026-09-18)

Uygulama işlevsel olarak tamamlandı: disk algılama (donanım kimliği ile), opt-in indeksleme, diff tabanlı yeniden tarama, FTS5 arama, klasör gezintisi, sıralama, kolon boyutlandırma, TR/EN arayüz, kompakt görünüm, özel etiketler, portable `.exe`. **GitHub'da yayınlandı.**

**Asla yapılmayacaklar (askıda):** G6/G7/G9 — MFT/USN tabanlı hızlandırma. Saf JS ile mümkün değil; Rust toolchain gerektirir. Mevcut ölçümler (NVMe 237k=28 sn, HDD 5k=5 sn) yeterli bulundu; gerçek ihtiyaç doğmadan ele alınmayacak.

**Olası ileri işler (talep olursa):** klasör seviyesinde hariç tutma, son tarananlar listesi, dosya önizleme/açma, dosya sistemi değişiklik izleyicisi.